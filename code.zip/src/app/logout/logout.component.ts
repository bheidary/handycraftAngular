import { Component, OnInit } from '@angular/core';
import {UserDbService} from '../services/user-db.service';
import {AuthDbaService} from '../services/auth-dba.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  newseller={};
  userData:any;
  constructor(private authservice: AuthDbaService,private userDatabase: UserDbService,private router: Router) { }
  ngOnInit(){
    this.authservice.setUserData(this.newseller);
    this.userDatabase.save(this.newseller);

    this.authservice.currentUser.subscribe(data=>{
      this.userData=data;
    });
   // window.location.reload();
   // this.router.navigate(['']);
   // this.router.routeReuseStrategy.shouldReuseRoute([/]);
   // location.reload();
  }
}

import { Component, OnInit } from '@angular/core';
import {mockedCategories} from '../../services/data/categoryList';
import {ActivatedRoute, Router} from '@angular/router';
import {mockedProducts} from '../../services/data/productLists';
import {mockedTitles} from '../../services/data/titles';
import {ProductBackendService} from '../../services/product-backend.service';
import {MatDialog} from '@angular/material';
import {AuthDbaService} from '../../services/auth-dba.service';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {
  userData:any;
  product={};
  sellerProducts:any=[];
  username;
  password;
  constructor(private authservice:AuthDbaService,private productBackendService:ProductBackendService, private router:Router, private activateRoute:ActivatedRoute) {

  }

  async ngOnInit() {
    this.authservice.currentUser.subscribe(data=>{
      this.userData=data;
      console.log("this.userData", data);
    });

  }

}

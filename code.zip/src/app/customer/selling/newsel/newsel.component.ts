import { Component, OnInit } from '@angular/core';
import {mockedCategories} from '../../../services/data/categoryList';
import {ProductBackendService} from '../../../services/product-backend.service';
import {ActivatedRoute, Router} from '@angular/router';
import 'rxjs/add/operator/take';

@Component({
  selector: 'app-newsel',
  templateUrl: './newsel.component.html',
  styleUrls: ['./newsel.component.css']
})
export class NewselComponent implements OnInit {
  product:any={};
  categories;
  selected ;
  url: string;
  file;
  selectFieSize =0;
  sellerID;
  constructor(private productBackendService:ProductBackendService,
              private router:Router,
              private activateRoute:ActivatedRoute) {
    this.categories= mockedCategories;
    this.sellerID=this.activateRoute.snapshot.paramMap.get('id');
    console.log(this.sellerID);
    //let id= this.activateRoute.snapshot.paramMap.get('id');
  //  if(id) this.productBackendService.getProductById(id).take(1).subscribe(item=>this.product=item);
  }

  ngOnInit() {
  }

  onSelectFile(event){
    this.file = event.target.files[0];
    console.log(this.file.size);
    this.selectFieSize = this.file.size;
  }


  save(formvalue){
    console.log(formvalue);
    this.product={"sellerID":this.sellerID,"name":formvalue.name,"numbers":formvalue.Numbers,"price":formvalue.price,"lng":"","lat":"","image":formvalue.image,"category":formvalue.category,"productDateIn":"","productExpireDate":"","description":formvalue.description,"keywoards":formvalue.keywoards,"status":"ACTIVE"};
    //this.product={"sellerID":formvalue.sellerID,"name":formvalue.name};
    console.log(this.product);
    this.productBackendService.saveProduct(this.product);
    this.router.navigate(['customer/1']);
  }

}

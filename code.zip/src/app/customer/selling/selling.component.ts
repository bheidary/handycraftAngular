import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ProductBackendService} from '../../services/product-backend.service';
import {DialogdelistComponent} from './dialogdelist/dialogdelist.component';
import {MatDialog} from '@angular/material';
import {AuthDbaService} from '../../services/auth-dba.service';
import {DialogLoginComponent} from '../../dialog-overview-example-dialog/dialog-login.component';
import {DialogsoldComponent} from './dialogsold/dialogsold.component';

@Component({
  selector: 'app-selling',
  templateUrl: './selling.component.html',
  styleUrls: ['./selling.component.css']
})
export class SellingComponent implements OnInit {
  userData:any;
  product={};
  sellerProducts:any=[];
  username;
  password;
  constructor(private authservice:AuthDbaService,
              private productBackendService:ProductBackendService,
              private router:Router,
              public dialog: MatDialog,
              private activateRoute:ActivatedRoute) {
  }

  async ngOnInit() {
    this.authservice.currentUser.subscribe(data=>{
      this.userData=data;
      this.productBackendService.getSellerProducts(this.userData.sellerId).subscribe(p=>this.sellerProducts=p);
      console.log("this.userData", data);
    });
}

  openDialogsold(productID): void {
    console.log("productID",productID);
    const dialogRef = this.dialog.open(DialogsoldComponent, {

      width: '350px',
      height: '250px',

      data: {productID: productID}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      this.username = result;
    });
  }
  openDialogdelist(productID): void {
    const dialogRef = this.dialog.open(DialogdelistComponent, {

      width: '350px',
      height: '250px',
      data: {productID: productID}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      this.username = result;
    });
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatDialogModule, MatTableModule,MatTabsModule } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';

import {SellerproductsComponent} from './products/sellerproducts/sellerproducts.component';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider, LinkedinLoginProvider,
} from 'angular-6-social-login';

import {AuthDbaService} from './services/auth-dba.service';
import {AuthGuardService} from './services/auth-guard.service';
import {UserDbService} from './services/user-db.service';
import {ProductBackendService} from './services/product-backend.service';
import {HttpClientModule} from '@angular/common/http';

/*import {
  MdButtonModule,
  MdCheckboxModule,
  MdChipsModule,
  MdDatepickerModule,
  MdExpansionModule,
  MdIconModule,
  MdInputModule,
  MdMenuModule,
  MdNativeDateModule,
  MdSelectModule,
  MdSidenavModule
} from '@angular/material';*/

import 'hammerjs';
import {MatButtonModule, MatCheckboxModule, MatChipsModule, MatInputModule, MatSelectModule} from '@angular/material';
import {MatFormFieldModule} from '@angular/material';
import {FileSizeModule} from 'ngx-filesize';
import { ProductDetailsComponent } from './products/product-details/product-details.component';
import { DialogLoginComponent } from './dialog-overview-example-dialog/dialog-login.component';
import {CustomerComponent} from './customer/customer.component';
import { SellingComponent } from './customer/selling/selling.component';
import { BuyingComponent } from './customer/buying/buying.component';
import { WatchlistComponent } from './customer/watchlist/watchlist.component';
import { ReviewsComponent } from './customer/reviews/reviews.component';
import { MessagesComponent } from './customer/messages/messages.component';
import { DetailselComponent } from './customer/selling/detailsel/detailsel.component';
import { EditdetailselComponent } from './customer/selling/editdetailsel/editdetailsel.component';
import { NewselComponent } from './customer/selling/newsel/newsel.component';
import { SellerslistComponent } from './admin/sellerslist/sellerslist.component';
import { ProductslistComponent } from './admin/productslist/productslist.component';
import { VerifyComponent } from './customer/verify/verify.component';
import {LogoutComponent} from './logout/logout.component';
import { DialogsoldComponent } from './customer/selling/dialogsold/dialogsold.component';
import {DialogdelistComponent} from './customer/selling/dialogdelist/dialogdelist.component';
import { DialogsignupComponent } from './dialogsignup/dialogsignup.component';
import { ProductChatComponent } from './products/product-chat/product-chat.component';
import { SearchproductComponent } from './products/searchproduct/searchproduct.component';




// Configs
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: FacebookLoginProvider.PROVIDER_ID,
        provider: new FacebookLoginProvider('876291656058810')
      },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider('507412302339-pjv2a3knpctrp7ch92tv10n02idecmm1.apps.googleusercontent.com')
      },
      {
        id: LinkedinLoginProvider.PROVIDER_ID,
        provider: new LinkedinLoginProvider('1098828800522-m2ig6bieilc3tpqvmlcpdvrpvn86q4ks.apps.googleusercontent.com')
      },
    ]
);
  return config;
}


// @ts-ignore
@NgModule({
  imports: [
    MatTableModule,
    BrowserModule,
    FormsModule,
    //for file size
    FileSizeModule,
    ReactiveFormsModule,
//for material
    MatTabsModule,
    BrowserAnimationsModule,
    MatButtonModule, MatCheckboxModule,
    MatFormFieldModule, MatInputModule,MatSelectModule, MatChipsModule,
    MatDialogModule,MatIconModule,


    SocialLoginModule,
    NgbModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent },
      { path: 'products', component: ProductsComponent },
      { path: 'products/details/:id', component: ProductDetailsComponent },
      { path: 'products/detailschat/:id', component: ProductChatComponent },
      { path: 'products/detailschat', component: ProductChatComponent },
      {path : 'products/sellerproducts/:id',component:SellerproductsComponent},
      {path:'products/search/:id',component:SearchproductComponent},
      { path: 'login', component: DialogLoginComponent },
      { path: 'logout', component: LogoutComponent },
      {path:'verify',component:VerifyComponent},
      {path:'customer',component:CustomerComponent},
      { path: 'customer/:id', component: CustomerComponent },
      { path: 'detailsel', component: DetailselComponent },
      { path: 'detailsel/:id', component: DetailselComponent },
      {path: 'editdetailsel',component:EditdetailselComponent},
      {path: 'editdetailsel/:id',component:EditdetailselComponent},
      {path: 'newsel/:id',component:NewselComponent},
      {path: 'sellerslist',component:SellerslistComponent},
      {path: 'sellerslist/:id',component:SellerslistComponent},
      {path: 'productslist',component:ProductslistComponent,canActivate:[AuthGuardService]},
      {path: 'productslist/:id',component:ProductslistComponent},
<<<<<<< HEAD
    ])
=======


    ],{onSameUrlNavigation: 'reload'})
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
  ],
  declarations: [
    AppComponent,
    ProductsComponent,
    SellerproductsComponent,
    NavbarComponent,
    HomeComponent,
    ProductDetailsComponent,
    DialogLoginComponent,
    LogoutComponent,
    CustomerComponent,
    SellingComponent,
    BuyingComponent,
    WatchlistComponent,
    ReviewsComponent,
    MessagesComponent,
    DetailselComponent,
    EditdetailselComponent,
    NewselComponent,
    SellerslistComponent,
    ProductslistComponent,
    VerifyComponent,
    DialogsoldComponent,
    DialogdelistComponent,
    DialogsignupComponent,
    ProductChatComponent,
    SearchproductComponent,
  ],
  providers: [
    AuthDbaService,
    AuthGuardService,
    UserDbService,
    ProductBackendService,
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }
  ],
  bootstrap: [AppComponent],
  entryComponents:[
    DialogsoldComponent,
    DialogLoginComponent,
    DialogdelistComponent,
    DialogsignupComponent
  ],
  exports: [RouterModule]
})
export class AppModule { }

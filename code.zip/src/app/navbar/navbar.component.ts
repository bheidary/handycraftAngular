import { Component, OnInit } from '@angular/core';
import {AuthDbaService} from '../services/auth-dba.service';
import {mockedCategories} from '../services/data/categoryList';
import {DialogLoginComponent} from '../dialog-overview-example-dialog/dialog-login.component';
import {MatDialog} from '@angular/material';
import {ProductBackendService} from '../services/product-backend.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  userData:any;
  promtionType:any;
  categories$;
  username;
  password;
  islogin:boolean;
  searchtext;
  constructor(private authservice:AuthDbaService,
              public dialog: MatDialog,
              private router: Router,
              private backendService:ProductBackendService
  ) {
    this.categories$=mockedCategories;
  }
  async ngOnInit() {
    this.authservice.currentUser.subscribe(data=>{
      this.userData=data;
      console.log("this.userData 1",this.userData)
      if(data){
        this.islogin=false;
        this.promtionType=data.promotionType;
        console.log("this.promtionType 1",this.promtionType);
        if((isNaN(data.id)).toString()==="false")     this.islogin=true;
        console.log("this.islogin 1",this.islogin);
      }
    });
    //TODO save data in database;
  }
   openDialog(): void {
        if(this.userData){
          if((isNaN(this.userData.id)).toString()==="false") {
            this.router.navigate(['/newsel/' + this.userData.sellerId]);
          }
          else     this.opend();
          }
        else     this.opend();
  }
  opend():void {
    const dialogRef = this.dialog.open(DialogLoginComponent, {
      width: '360px',
      height: '560px',
     // data: {name: this.username, password: this.password}
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      this.username = result;
    });
  }
  testauth(){
    this.backendService.auth2test();
  }

  sendSwishRequest(){
   // this.swishService.sendRequest(100);
  }
  searchpro(formvalue){
    this.router.navigate(['products/search/' + formvalue.searchtext]);
  }
}

import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/internal/BehaviorSubject';
import {UserDbService} from './user-db.service';

@Injectable()
export class AuthDbaService {
  userData: any;
  isLogged = false;

  private data = new BehaviorSubject<any>(null);
  currentUser = this.data.asObservable();

  constructor(private userDatabase: UserDbService) {
  }

  setUserData(data: any) {
    let dataDto: any=[];

    dataDto.id = data.id;
    dataDto.sellerId = data.sellerId;
    dataDto.name = data.name;
    dataDto.image = data.image;
    dataDto.email = data.email;
    dataDto.promotionType = data.promotionType;
  //  if (this.userDatabase.getUser(data.id))
  //  if (this.userDatabase.getUser(data.id).promotionType == '2') {
 //     dataDto.promotionType = true;
  //  }
    this.data.next(dataDto);
  }
  setUserData2(data: any) {
    let dataDto: any=[];

    dataDto.id = data.userName;
    dataDto.sellerId = data.sellerId;
    dataDto.name = data.name;
    dataDto.image = data.imageLink;
    dataDto.email = data.email;
    dataDto.promotionType = data.promotionType;
 //   if (this.userDatabase.getUser(data.userName))
  //    if (this.userDatabase.getUser(data.userName).promotionType == '2') {
  //      dataDto.promotionType = true;
 //     }
    this.data.next(dataDto);
  }

  getUserData(): any {
    return this.data;
  }

  isLoggedIn() {
    return this.isLogged;
  }

}

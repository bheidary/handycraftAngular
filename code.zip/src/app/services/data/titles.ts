export  const mockedTitles=[
// {headerName: 'id', field: 'id', sortable: true },
// {headerName: 'sellerID', field: 'sellerID' , sortable: true},
{headerName: 'name', field: 'name'},
{headerName: 'category', field: 'category',filter: true},
{headerName: 'description', field: 'description'},
{headerName: 'image', field: 'image'},
/*{headerName: 'productDateIn', field: 'productDateIn'},
{headerName: 'productExpireDate', field: 'productExpireDate'},*/
{headerName: 'price', field: 'price'},
{headerName: 'numbers', field: 'numbers'},
{headerName: 'keywoards', field: 'keywoards'}
]
// "id","sellerID","name","category", "description","image","productDateIn",
//   "productExpireDate",
//   "lat",
//   "lng",
//   "",
//   "",
//   "keywoards"

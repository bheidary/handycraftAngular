export const mockedProducts =
  [


    {
      "productID": 1,
      "sellerID": 12,
      "name": "TV",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/201",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 0,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 2,
      "sellerID": 12,
      "name": "Bed",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/202",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 0,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 3,
      "sellerID": 12,
      "name": "chair",
      "category": "Sports",
      "description": "string",
      "image": "https://picsum.photos/203",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 0,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 4,
<<<<<<< HEAD
      "sellerID": 12,
=======
      "sellerID": 17,
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
      "name": "computer",
      "category": "computer",
      "description": "string",
      "image": "https://picsum.photos/210",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 0,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 5,
<<<<<<< HEAD
      "sellerID": 12,
=======
      "sellerID": 17,
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
      "name": "mobile",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/219",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
<<<<<<< HEAD
      "productID": 5,
      "sellerID": 12,
=======
      "productID": 6,
      "sellerID": 17,
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
      "name": "mobile",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/220",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID":6,
      "sellerID": 12,
      "name": "mobile",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/221",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 7,
      "sellerID": 12,
      "name": "mobile",
      "category": "string",
      "description": "string",
      "image": "https://picsum.photos/222",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 8,
      "sellerID": 12,
      "name": "mobile",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/223",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 10,
      "sellerID": 12,
      "name": "mobile",
      "category": "Sports",
      "description": "string",
      "image": "https://picsum.photos/224",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 11,
      "sellerID": 12,
      "name": "mobile",
      "category": "Electronics",
      "description": "string",
      "image": "https://picsum.photos/225",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 2000,
      "numbers": 0,
      "keywoards": "string"
    },
    {
      "productID": 9,
      "sellerID": 5,
      "name": "mobile",
      "category": "Cars",
      "description": "string",
      "image": "https://picsum.photos/227",
      "productDateIn": "2019-02-12T22:40:47.273+0000",
      "productExpireDate": "2019-02-12T22:40:47.273+0000",
      "lat": 0,
      "lng": 0,
      "price": 1000,
      "numbers": 0,
      "keywoards": "string"
    }
  ]

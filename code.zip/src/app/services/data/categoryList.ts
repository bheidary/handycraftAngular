export const mockedCategories =[
  {"category":"Home"},
  {"category":"Electronics"},
  {"category":"Sports"},
  {"category":"Pets"},
  {"category":"Cars"},
  {"category":"Property"},
  {"category":"computer"},
  {"category":"Phone"}
];

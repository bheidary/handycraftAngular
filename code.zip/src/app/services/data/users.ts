export const mockedUsers =
  [
    {
      "id": "113991223868978316044",
      name: "maghnus ",
      email: "matbidekani@gmail.com",
      image: "https://lh4.googleusercontent.com/-FFQaBRCE2jM/AAA…CevoQP0KPEOtXMVfVn8YlCAiiyCPbtrLw/s96-c/photo.jpg",
      promotionType:"2"
    },
    {
      "id": "10",
      name: "Markos ",
      email: "matbidekani@gmail.com",
      image: "https://lh4.googleusercontent.com/-FFQaBRCE2jM/AAA…CevoQP0KPEOtXMVfVn8YlCAiiyCPbtrLw/s96-c/photo.jpg",
      promotionType:"3"
    },
    {
      "id": "200",
      name: "Mattias ",
      email: "matbidekani@gmail.com",
      image: "https://lh4.googleusercontent.com/-FFQaBRCE2jM/AAA…CevoQP0KPEOtXMVfVn8YlCAiiyCPbtrLw/s96-c/photo.jpg",
      promotionType:"0"
    },
    {
      "id": "300",
      name: "Matthew ",
      email: "matbidekani@gmail.com",
      image: "https://lh4.googleusercontent.com/-FFQaBRCE2jM/AAA…CevoQP0KPEOtXMVfVn8YlCAiiyCPbtrLw/s96-c/photo.jpg",
      promotionType:"4"
    },
    {
      "id": "101055767556370567472",
      name: "Bahram Heidary ",
      email: "bahram.heidary@gmail.com",
      image: "https://lh4.googleusercontent.com/-iAsqkMDfMUk/AAAAAAAAAAI/AAAAAAAAADY/dHEf7dyQw-M/s96-c/photo.jpg",
      promotionType:"2"
    }
  ]

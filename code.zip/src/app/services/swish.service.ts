
'use strict';
import { Injectable } from '@angular/core';
// import swish = require('swish-payment');

@Injectable()
export class SwishService {

  constructor() {

    /*swish.init({
      cert: {
        key: 'res/certs/swish.key',
        cert: 'res/certs/swish.crt',
        ca: 'res/certs/swish.ca',
        passphrase: 'swish'
      },
      data: {
        payeeAlias: '1231181189',
        currency: 'SEK',
        callbackUrl: 'https://www.localhost:4200'
      }
    });*/
  }


  sendRequest(amount){
    // /*swish.add({
    //   payeePaymentReference: "snus123",
    //   payerAlias: '0762592501',
    //   amount: "100",
    //   message: "Handy craft Test"
    // })
    //   .then(function(id) {
    //     console.log(id);
    //   });*/
  }

  getRequestById(id){
    // swish.get(id)
    //   .then(function(data) {
    //     console.log(data);
    //   });
  }


}

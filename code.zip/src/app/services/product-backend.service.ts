import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import {Observable} from "rxjs/Observable";
import {map} from 'rxjs-compat/operator/map';

import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class ProductBackendService {
  private token = "Basic ";
<<<<<<< HEAD
  URI='http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/products';

=======
  URI='http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/pr/products';
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
  constructor(private http: HttpClient) { }






///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////
      ///////////////////////////////////       Products       ///////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////Get All Products///////////////////////////
  getAllData():Observable<any>{
    let headers = new HttpHeaders().
<<<<<<< HEAD
       set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
return this.http.get(this.URI,{headers:headers});
  }
  //////////////////////////////////////////////////////Get All Sellers///////////////////////////
  getAllSellers():Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/users',{headers:headers});
  }
  /////////////////////////////////////////////////////  Add  Sellers   ////////////////////////////////
  saveSeller(seller){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/users/',seller, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
  ///////////////////////////////////////// Get Seller By ID ////////////////////////////
  getSellerById(SellerID):Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get('hhttp://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/users/'+SellerID,{headers:headers});
=======
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get(this.URI,{headers:headers});
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
  }
  /////////////////////////////////////////search in product name and categories and keywords///////////////////////////
  searchproduct(searchtext):Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
<<<<<<< HEAD
    return this.http.get('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/users/email/'+SellerEmail,{headers:headers});
  }
  ///////////////////////////////////////// Update Seller ////////////////////////////
  updateSeller(seller){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/users',seller, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
////////////////////////////////////////////////////  //////////////////////////////////////
  private extractData(res: any) {

    let body = res.json();
    return body || [];
  }

  private handleError(error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
=======
    return this.http.get(this.URI + '/search?searchItem=' + searchtext,{headers:headers});
>>>>>>> 22615b436fd521837d270cf9f40e4f6c22ffbcac
  }
  //////////////////////////////////////////////////////Save Product///////////////////////////
saveProduct(product){
  const headers = new HttpHeaders()
    .set("Content-Type", "application/json");
  return this.http.post(this.URI,product, {headers:headers}).subscribe(
    val => {
      console.log("POST call successful value returned in body",
        val);
    },
    response => {
      console.log("POST call in error", response);
    },
    () => {
      console.log("The POST observable is now completed.");
    }
  );
}
  //////////////////////////////////////////////////////update Product///////////////////////////
  updateProduct(productid,product){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post(this.URI+'/'+productid,product, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
  //////////////////////////////////////////////////////Get Product By ID///////////////////////////
getProductById(productID):Observable<any>{
  let headers = new HttpHeaders().
  set('Accept', 'application/json');
  return this.http.get(this.URI+'/'+productID,{headers:headers});
}
  //////////////////////////////////////////////////////Get Seller Products///////////////////////////
getSellerProducts(sellerId):Observable<any> {
  let url = 'http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users/';

  let headers = new HttpHeaders().
  set('Accept', 'application/json');
  return this.http.get(url+ sellerId + '/products',{headers:headers});
}

auth2test() {
  const headers = new HttpHeaders()
    .set("Content-Type", "application/x-www-form-urlencoded")
    .set("Authorization", "Basic $2a$08$fL7u5xcvsZl78su29x1ti.dxI.9rYO8t0q5wk2ROJ.1cdR53bmaVG");
  let cont={
    "grant_type":"password",
    "username":"a257885",
    "password":"10661066"
  }
  return this.http.post(this.URI,cont, {headers:headers}).subscribe(
    val => {
      console.log("POST call successful value returned in body",
        val);
    },
    response => {
      console.log("POST call in error", response);
    },
    () => {
      console.log("The POST observable is now completed.");
    }
  );
}





  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////       Sellers       ///////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////Get All Sellers///////////////////////////
  getAllSellers():Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get('http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users',{headers:headers});
  }
  /////////////////////////////////////////////////////  Add  Sellers   ////////////////////////////////
  saveSeller(seller){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users/',seller, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
  ///////////////////////////////////////// Get Seller By ID ////////////////////////////
  getSellerById(SellerID):Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get('http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users/'+SellerID,{headers:headers});
  }
  //////////////////////////////////// ///// Get Seller By Email ////////////////////////////
  getSellerByEmail(SellerEmail):Observable<any>{
    let headers = new HttpHeaders().
    set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .set('Authorization', this.token);
    return this.http.get('http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users/email/'+SellerEmail,{headers:headers});
  }
  ///////////////////////////////////////// Update Seller ////////////////////////////
  updateSeller(seller){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://demo-handcraft.1d35.starter-us-east-1.openshiftapps.com/v1/se/users',seller, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
////////////////////////////////////////////////////  //////////////////////////////////////
  private extractData(res: any) {

    let body = res.json();
    return body || [];
  }

  private handleError(error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }


///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////       Favorites       ///////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////Get All Favorite///////////////////////////
  getAllFavorite():Observable<any> {
    let url = 'http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/favorites';

    let headers = new HttpHeaders().
    set('Accept', 'application/json');
    return this.http.get(url,{headers:headers});
  }
  /////////////////////////////////////////////////////  Add  Favorite   ////////////////////////////////
  AddFavorite(seller){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/favorites',seller, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
  /////////////////////////////////////////////////////  Del  Favorite   ////////////////////////////////
  delFavorite(userid,productid){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.delete('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/favorites/users/' + userid + '/products/'+  productid, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
  //////////////////////////////////////////////////////getIfUserFavorites ///////////////////////////
  getIfUserFavorites(userid,productid):Observable<any> {
    let url = 'http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/favorites';

    let headers = new HttpHeaders().
    set('Accept', 'application/json');
    return this.http.get(url + '/users/' +userid + '/products/' + productid ,{headers:headers});
  }
  //////////////////////////////////////////////////////// list all favorited of a User   ///////////////////////////
  listAllFavoritedOfAUser(userid):Observable<any> {
    let url = 'http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/pr/favorites/';

    let headers = new HttpHeaders().
    set('Accept', 'application/json');
    return this.http.get(url + userid  ,{headers:headers});
  }










///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////       Reating       ///////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////Get User Reating ///////////////////////////
  getUserRating(sellerid):Observable<any> {
    let url = 'http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/rates/sellers/';

    let headers = new HttpHeaders().
    set('Accept', 'application/json');
    return this.http.get(url+ sellerid,{headers:headers});
  }






///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////       Messages       ///////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  ///////////////////////////get message by sender, reciever and prodcut to make the chatlist//////////////////////////
  getMessage(buyerid,sellerid,productid):Observable<any> {
    let url = 'http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/messages/senders/';

    let headers = new HttpHeaders().
    set('Accept', 'application/json');
    return this.http.get(url+ buyerid + '/reciever/' + sellerid + '/products/' + productid,{headers:headers});
  }
  /////////////////////////////////////////////////////// send a new message  ////////////////////////////////
  sendNewMessage(newmessage){
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json");
    return this.http.post('http://handy-demo-handcraft.7e14.starter-us-west-2.openshiftapps.com/v1/se/messages/',newmessage, {headers:headers}).subscribe(
      val => {
        console.log("POST call successful value returned in body",
          val);
      },
      response => {
        console.log("POST call in error", response);
      },
      () => {
        console.log("The POST observable is now completed.");
      }
    );
  }
}
